from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import speech_recognition as sr

def classify_emotion(sentiment_scores):
    # Define thresholds for different emotions
    emotion_thresholds = {
        'anger': 0.5,
        'sadness': -0.5,
        'happiness': 0.5,
        'fear': -0.5,
        'crying': -0.5,
    }

    # Classify sentiment into emotions based on thresholds
    emotion = 'neutral'
    for emo, threshold in emotion_thresholds.items():
        if sentiment_scores['compound'] >= threshold:
            emotion = emo
            break

    return emotion

recognizer = sr.Recognizer()

with sr.Microphone() as source:
    print('Clearing background noise...')
    recognizer.adjust_for_ambient_noise(source, duration=1)
    print('Waiting for your message...')
    recordedaudio = recognizer.listen(source)
    print('Done recording..')

try:
    print('Printing the message..')
    text = recognizer.recognize_google(recordedaudio, language='en-US')
    print('Your message: {}'.format(text))

    # Sentiment analysis
    Sentence = [str(text)]
    analyser = SentimentIntensityAnalyzer()
    for i in Sentence:
        sentiment_scores = analyser.polarity_scores(i)
        print(sentiment_scores)

        # Classify emotion
        emotion = classify_emotion(sentiment_scores)
        print('Emotion: {}'.format(emotion))

except Exception as ex:
    print(ex)
