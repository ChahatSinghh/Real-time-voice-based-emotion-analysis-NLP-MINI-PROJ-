import speech_recognition as sr
from pysentimiento import create_analyzer

# Create the emotion analyzer
emotion_analyzer = create_analyzer(task="emotion", lang="en")

# Initialize the speech recognizer
recognizer = sr.Recognizer()
microphone = sr.Microphone()

def capture_and_analyze_emotion():
    with microphone as source:
        print("Please speak something...")
        audio = recognizer.listen(source)

    try:
        text = recognizer.recognize_google(audio)
        emotion_result = emotion_analyzer.predict(text)
        return text, emotion_result
    except sr.UnknownValueError:
        return "", None
    except sr.RequestError as e:
        print("Error: ", e)
        return "", None

while True:
    transcribed_text, emotion_result = capture_and_analyze_emotion()
    if transcribed_text:
        print("Transcribed Text:", transcribed_text)
        if emotion_result:
            print("Emotion Analysis Result:", emotion_result)
            break  # Exit the loop after getting the first output
