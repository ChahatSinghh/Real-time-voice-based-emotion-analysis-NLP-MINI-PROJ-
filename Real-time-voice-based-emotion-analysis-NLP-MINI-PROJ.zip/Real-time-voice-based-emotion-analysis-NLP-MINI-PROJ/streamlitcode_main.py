import streamlit as st
import speech_recognition as sr
from pysentimiento import create_analyzer
from PIL import Image

#loading image
img=Image.open('emotion-analysis.jpg')

# Create the emotion analyzer
emotion_analyzer = create_analyzer(task="emotion", lang="en")

# Initialize the speech recognizer
recognizer = sr.Recognizer()
microphone = sr.Microphone()

# Set the page title and icon
st.set_page_config(page_title="Real-time Emotion Analysis", page_icon="🎙️")

# Add a custom CSS stylesheet to enable dark mode
st.markdown(
    """
    <style>
    .stApp {
        background-color: #121212;
        color: #ffffff;
    }
    .stButton > button {
        background-color: #4f4f4f;
        color: #ffffff;
    }
    .stButton > button:hover {
        background-color: #666666;
        color: #ffffff;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

st.title("Real-time Emotion Analysis from Audio")

def capture_and_analyze_emotion():
    with microphone as source:
        st.write("Please speak something...🎙️")
        audio = recognizer.listen(source)

    try:
        text = recognizer.recognize_google(audio)
        emotion_result = emotion_analyzer.predict(text)
        st.write("Transcribed Text:", text)
        main_output = emotion_result.output
        st.write("Emotion is:", main_output)
        st.write("Emotion Analysis Result:", emotion_result)
        return True
    except sr.UnknownValueError:
        st.write("Audio not recognized.")
        return False
    except sr.RequestError as e:
        st.write("Error: ", e)
        return False

if st.button("Start"):
    while not capture_and_analyze_emotion():
        pass  # Keep capturing until audio is successfully recognized

st.write("Analysis completed.")
st.image(img, caption=None, width=None, use_column_width=None, clamp=False, channels='RGB', output_format='auto')

#use this to run streamlit
#python -m streamlit run streamlitcode,py